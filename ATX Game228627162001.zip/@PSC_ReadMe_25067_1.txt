Title: ATX Game
Description: [ ---- AtX-Game ---- ]
A new break out game but with a lot of stuff, 13 levels, a monster that you have to shoot, a remember of the hi scores, &#8230;
Look at the screenshot, play the 13 levels out, go to my website for more information about the game and then VOTE4ME&#8230;.
The only disadvantage is that you need a pentium II with windows NT.
I thank U All   [ ----AntraX---- ] 

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=25067&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
