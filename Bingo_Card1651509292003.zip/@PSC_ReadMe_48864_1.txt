Title: Bingo Card for VZones
Description: This is the code for a started Bingo card for the world of VZones. This uses the standard game format and lets you make your own games but does not support games like 1 line. I never finished this and really have no plans to so I thought I would release the source. Enjoy!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=48864&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
