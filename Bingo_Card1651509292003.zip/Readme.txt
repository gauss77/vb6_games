--- Bingo XP code by Coal/Jason - jason@filex.org - http://www.filex.org ---

 I am releasing this because I do not plan on adding to it anymore and I
 can not even gaurantee it is bug free since I never released it. This is
 something I think can help the other programmers out there that are looking
 for information on how to make a bingo card for VZones/Vzones.com. This project
 is as good a start as any since it has stuff like custom games which other
 bingo cards lack sometimes :) If you use this code maybe give me a shoutout or
 something in your program, atleast send me an email so I can check out what ya
 made! :P