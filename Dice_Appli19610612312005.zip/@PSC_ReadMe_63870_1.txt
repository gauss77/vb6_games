Title: Dice Application
Description: This program allows you to roll 1 or 2 dice from 0-6, with 2 it is 0-12. You can activate and de-activate the second dice. This program is useful when you lack dices for board games. Enjoy!
PS: Please rate the program!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=63870&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
