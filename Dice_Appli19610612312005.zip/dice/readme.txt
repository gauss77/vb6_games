This program allows you to roll 1 or 2 dice from 0-6, with 2 it is 0-12. You can activate and de-activate the second dice. This program is useful when you lack dices for board games. Enjoy!

PS: Please rate the program!