Title: Breakout Example
Description: A good example of how to create a breakout style game using BitBlt. Can be changed to run at most resolutions...but optimized for 640x480. It is some code that i abandoned for DX7. Feel free to use this code fot whatever..but a mention in credits would be nice.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=24048&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
