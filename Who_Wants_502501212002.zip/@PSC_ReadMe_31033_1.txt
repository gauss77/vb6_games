Title: Who Wants To Be a Millionairre (MMM)
Description: I put this on again because I need to see what the edit function was "sorry, dont think im just trying to get more votes"
Please Vote even if its only worth 1 globe because its disrespectful to a coder to not give him/her feedback on there hardwork!!!!!!!!
This is a great ripoff of the famous Who Want To Be A Millionairre Game. it includes all the lifelines. I will be adding more sets of questions soon. This can be used freely and I hope that people would add extra features and make it better so that I can learn from it.
I am only 13 so I think Its Quite good for my age.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=31033&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
