Title: Box Storm
Description: BoxStorm is a simple game made using some simple graphics techniques. It has multiple difficulty levels, sound and music. The basic idea behind the game is that you move your green block left and right under the red enemy blocks which are falling and fire to force them back to the top. You have to keep them at bay for 1 minute. I started this project two years ago (2003) and made the basic game. Eventually I gave up with the project due to school and other commitments. A few days ago I was looking through my VB Programs folder and spotted BoxStorm. I played on it for a bit and realised how hooked I was. It was buggy, but it was fun. So I started to work on it again and now it's done.
If you beat the "Harder than diamond" difficulty level, please tell me. I've tried it many times and the closest I got was 16 seconds left before I lost.
Enjoy!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=60562&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
