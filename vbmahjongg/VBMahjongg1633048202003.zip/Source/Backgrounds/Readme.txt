En este directorio puedes poner los graficos que se usaran como tapiz de fondo

El programa cargar� automaticamente los archivos que se encuentren en este directorio

- El tipo de archivos deber� ser *.jpg

- Hay 2 archivos por tapiz
	  El archivo "grande" debera ser de 936 x 676 pixels (aprox.)
	  El archivo "previsualizado" debera ser de 213 x 153 pixels
		El nombre del archivo "previsualizado" debera ser PREVxxxxx.jpg
