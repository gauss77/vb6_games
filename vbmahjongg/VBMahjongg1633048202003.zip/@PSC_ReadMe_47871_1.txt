Title: VBMahjongg Beta8 [Tiny version for Fixed Download]
Description: VBMahjongg 2.1 its a fully game write completly in visual basic with out any external DLL, Ocx or
libs. *See* the animated screen shot to believe it. This classical Chinese Game contais more than 100 varaitions of
original game, and give you the oportunity to make new ones with the level editor. New improved 
routine than makes all the puzzles have solution (i've seen some COMERCIAL Mahjongg puzzles that
generates un-solvables puzzles!). More than 30 Tilesets, Backgrounds, Midi Music and sound effects,
HallFame board, etc. The game supports several Languages. Only make the apropiate translation
file and put it on language folder and voil�...a new language its available. No re-code nothing.
The same occurs with TileSets, Musics and Backgrounds. This is not "easy" code. More than 14 Modules
and 10 Forms (yes, a optimization is needed, i know this xDD). See Readme.txt for *importat* notes.
Compile the code and run the executable for correct Menu Subclassing.
Especial Thanks goes to: Ren�-Gilles Deberdt (the original author of Kyodai Game), G. D. Sever (Menu
Sublassing routines), Kailash Nadh (for his Unveliable Screen Effects) and all the betatesters that
improve testing for this game around several weeks.
If you like this game, well...a vote will be apreciated..xDDD, and of course, any report (good or bad) will be
studied for future revisions.
PSC don't le me upload large files. 
For this reason this version not has all the graphics 
See you.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=47871&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
