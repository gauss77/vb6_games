This are the original BackGrounds for VBMahjongg:
http://www.planet-source-code.com/vb/scripts/ShowCode.asp?lngWId=1&txtCodeId=47871

Replace the original /Backgrounds folder on "tiny" version with the /Backgrounds on this ZIP