This are ZIP 1 of 3 of original Tilesets for VBMahjongg:
http://www.planet-source-code.com/vb/scripts/ShowCode.asp?lngWId=1&txtCodeId=47871
