Title: Battleship Game (multiplayer)
Description: This is an old game of Battleship that I loved to play as a kid. This version supports single and muli play over network or internet (winsock). It also includes a messanger. Have fun and please vote.
Please fill free to post comments and and more importantly report bugs. I know that there is a bug when you select Network Client and don't have an IP. If you know how to fix it please let me know. Another thing is that you can not test multiplay without compiling it does not work for some reason, but when you compile you can run 2 games simultaniously and play with yourself if you want.
If you can provide better animation for a miss or a better graphic for hit ship please send them to me. If any of the graphics I used are copyrighted let me know and I will take them off. Thank you.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=24844&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
