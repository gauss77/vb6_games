Title: Chess Engine (lowlevel) ver 2
Description: This is Chess game with engine implemented as activeX DLL project. It also displays computer thinkings. It currently thinks 1 level deep, but it could be easily changed (recursive).
Since this project exists for 2 months, it is buggy (engine doesn't have idea about castling; user can castle, also piece promotion is not yet implemeted)and incomplete. I plan to port code (when it'll be ready) to C++.
U will have big problems reading this code. It is very complicated plus comments and variables names are not in english. But on request I can translate at least comments...
User cannot drag pieces; he must type moves instead (like e2e4)...
U can use this code freely!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=22495&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
