Title: Connect 4 Game (Internet)
Description: Me and my friend had a weird obsession of playing Connect-4 while at camp. So one day while I was bored, I decided to create a computer program so I could play at home. I used very good coding techniques. Making a picture box and making sure no bugs exist in it. It is playable over an internet and should bypass most proxies. It also included a chat box to intimidate the player. I used an example of declaring your own types so this should be a great lesson for all!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=44992&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
