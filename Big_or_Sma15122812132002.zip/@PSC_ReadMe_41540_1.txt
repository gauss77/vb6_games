Title: Big or Small Game 3 (Fixed Error)
Description: Fixed: Exit Button, Saving High Score Code (Latest)!! New Features: Added a chance of winning bar!! This is a family game that give you 5 minutes of enjoyment, just like poker card. Hope you would like this game.!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=41540&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
