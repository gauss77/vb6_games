Title: DiabloSample
Description: Diablo like start of a game lots of cool options
three camera angles by pressing F5,6,7. animated
movement, camera follows character, 2d fire rising out of ground.
Please email me if there are any problems or questions.
mtari@mnsi.net
P.S. The object here is to show how some techniques can be used, the game is in no way complete.
This is to help others that were wondering how to do some of the things i did here.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=27518&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
