Title: Azteroids
Description: Version: Added Pause Function(P), fixed some bugs
Version: Fixed missing .BAS file
It's a game of asteroids, using classes, shapes, and trigonometry. I know it's been done before, but I got into the idea of doing it... Up cursor to thrust, Left & Right Cursor to turn, Space to fire. Escape to end. Runs well on PIII 500 Wint NT, I'd be interested to know how it runs under other O/S's. It's a lot easier to play at higher resolutions - 640 X 480 is too hard.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=32944&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
