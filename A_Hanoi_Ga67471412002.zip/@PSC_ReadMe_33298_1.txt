Title: A Hanoi Game by Rob
Description: I was bored one day and I said to myself, "Self, I think you should make a towers of Hanoi game."
I replied almost instantaneously, "Why Rob that's the best idea I've heard from you in a while."
So well we both got to work on this brilliant Towers of Hanoi game and we thought that we would share it with the WORLD!! Anyway if anyone can help us figure a recursive solution to this game I'm sure we would greatly appriciate it.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=33298&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
