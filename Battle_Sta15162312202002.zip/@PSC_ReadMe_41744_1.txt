Title: Battle Star (2 Players)
Description: This is like the game "Battle Ships" except it uses star ships of different shapes. Demonstrates BitBlt, Winsock & Simple Messaging Methods. Has been tested over the internet and Lan's. Just interested to find out what everyone thinks of this. This game is 100% complete !!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=41744&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
