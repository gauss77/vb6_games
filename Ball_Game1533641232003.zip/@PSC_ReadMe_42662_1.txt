Title: Ball Game
Description: Excellent Ball Game - There are 5 levels in this game, and 3 different speeds. 1st level balls are falling and u catch them in ur basket, 2nd u save ur casket from these balls, 3rd same like 1st except the balls move in all directions, 4th like 2nd but balls move in all direction. 5th u only catch the YELLOW balls if u catch red ball u get -1 point. 
You control the basket with the arrow keys! It is very cool and entertaining game, even if u dont wanna do any programmin u can play it for full time-pass :-) No OCX or DLLs are used, plz drop ur comment or visit: http://flash.to/indianshareware Thanq :-)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=42662&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
