Title: Dice Poker
Description: Dice Poker is a dice game like Yahtzee. Note that the name/word Yahtzee is trademarked by Hasbro, and this game is completely written by me, 
and completely unrelated to Hasbro. While Hasbro can trademark that word, they can't trademark the game rules (which I am given to understand 
originated in China). This game uses the same rules, only does not seek to confuse anyone by calling itself "Yahtzee".
This is a single-player game, in the production-wasting genre of Windows games Solitaire, Freecell, and Hearts (in fact, I wrote this game 
when I tired of playing those 3).
This is a fully fleshed out game, featuring code examples for Resource files, registry entries, custom control(ocx) creation (using my own 
custom polyhedral dice OCX spource code), property pages, and project groups. While the game itself is well documented, the Dice OCX is not, 
though it should be easy to follow. To open the entire project, you'll need to open DicePokerGroup.VBG.
This game and all source code is copyrighted (1999-2001) Gregory Lee Mahan (me). You may not distribute the game as-is for monetary gain. 
You may use the code as part of your own project provided author attribution is clearly given on the startup and help/about screens.
Such attribution shall read "Includes source code Copyrighted (1999-2001) by Gregory Lee Mahan herein used with permission".

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=24571&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
