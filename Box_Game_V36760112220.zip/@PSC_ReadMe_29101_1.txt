Title: Box Game Version 3.0
Description: This version is better than the last one because you really can't cheat. So have fun and vote please. I hope you like this version because you can't cheat on it so have fun...
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=29101&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
