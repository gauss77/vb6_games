Title: Big 2 Online (server and client)
Description: This is a Big 2 Game that use winsock to go online. The game is still being created and only features singles, doubles, triples and quads. Jokers and poker hands are sill being created. This was here for comments and feedbacks for future version and Ai tips. Hopefully a dedicated server will be out soon. Further instructions will be in the Read me File. Plz put comments. This was not created for the voting contest though.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=51775&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
