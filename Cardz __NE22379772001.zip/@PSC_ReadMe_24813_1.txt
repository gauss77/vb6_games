Title: Cardz **NEW**
Description: This is my first attempt at a scriptable card game, the code itself is not good at all but has got some bits going,what I intend to do is have an option to load in game scripts so that it is capable of simulating any card game. One problem I have though is not being able to obtain the Z order from a card, as it is a write only property, anyway, download it and see what you think, its got sound effects and nifty little graphics that i nicked of the web ;) lovely jubly. Please vote it if you think it's a good idea!!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=24813&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
