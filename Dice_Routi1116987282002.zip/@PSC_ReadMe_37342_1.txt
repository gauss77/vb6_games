Title: Dice Routine
Description: Dice routine. This small project will help you learn how to implement dice rolling in your game. This sample makes use of multiple timers, 6 to be exact, each managing its own die. All dice start and stop simultaneously. You can click on each die to hold a value. This project makes use of functions that take controls as parameters. This small project was fun to make. It was created as a 10 minute programming challenge between a friend of mine and my self. Clearly it took longer than 10 minutes, but hey, I got the dice rolling...
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=37342&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
