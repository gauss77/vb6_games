If your right click the form then this will start a new game.

Game Rules:
If you or the computer get 21 the person that gets it first wins
If you exceed 21 you lose
if your score is highr than the computer you win
an ace can value 11 or 1 
