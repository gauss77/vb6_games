Title: Astro Wars Complete Shooter !
Description: Complete space ship shooter you will learn a lot from it if you are making a game includes health system, and much more !!! Please vote if you like !
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=43835&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
