Title: A Drag Racin' Game *Upgraded*
Description: I uploaded this game earlier yesterday but now i made it better. You can visit my website at www.angelfire.com/freak/vbco/index.html. Now on this racing game you can bet to see if you win. Tip look at the tool tip for everything. Coming out soon a 2 player drag racin' game hope you like this one and I hope I win the montly contest. Please leave comments and those points on this game. Sorry no screenshot if someone could make a screenshot and post it up or send it to me: My e-mail is July1097@aol.com please do.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=30783&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
