Title: Black Winter 2: Final Assault
Description: Black Winter 2 (BW2) is the second space shooter in its series, featuring many main weapons, side weapons, special weapons, variety of enemies, and its regular end-of-level bosses. The game uses 24-bit graphics, image masking(bltblt), sound effects, background music, and realistic explosions. The game is written in well commented codes, a tutorial guide to help programmers to build a basic space shooter, and a printer-friendly user manual for gamers who wants quick reference on weapons and ship statistics.
Players are welcome to send to me their highscore files and up-to-date pilot standings will be published here. Votes for this submission are much appreciated. 
&lt;p/&gt;Top 10 Pilots: 
&lt;br/&gt;1. jzthealien (131220 - Killed LastBoss) 
&lt;br/&gt;2. Ryan Catling (118260 - Killed LastBoss)
&lt;br/&gt;3. Nafees Ahmad (116200 - Killed LastBoss)
&lt;br/&gt;4. Blaster Master (113435 - Killed LastBoss) 
&lt;br/&gt;5. David Albrecht (105905 - Killed LastBoss) 
&lt;br/&gt;6. tt_Hydra (105635 - Killed LastBoss) 
&lt;br/&gt;7. Ronald Borla (105520 - Killed LastBoss) 
&lt;br/&gt;8. Alejandro Villarreal (103195) 
&lt;br/&gt;9. Ryan Catling (102665 - Killed LastBoss)
&lt;br/&gt;10. Gert Eising (98680) 
&lt;p/&gt;Rename msdxm.oc_ to msdxm.ocx, if that doesnt work you can download a public copy from http://freeware.it-mate.co.uk/?Cat=OCX_Files
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=42072&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
