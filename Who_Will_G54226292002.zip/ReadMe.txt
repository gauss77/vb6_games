~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
Who Will Guess the Number First?
An addictive online multiplayer game by DasHSofTR
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

I don't know what to say in a readme, yeah..

But as they all say, as long as you don't use it for commercial purposes and hold this readme with the code or the program, you shall contribute it freely, but i'd like to see its path, so please email me if you can, with the help of the proggie. If you wish to take a part of the code, just credit me...


- How to play?

     It's really simple.
     Trust your wits, and then find a friend to play with.
     Be either the "Server" to host the game or the "Client" to connect to your friend who will become the "Server". If you are the server, you will find your IP adress of your computer in the status bar. Give that number to your friend and (s)he should exactly write it in the box in the "Connect" button and then click it. You will be asked of permission, which enables you to refuse any other connections established by another IP address.
     After you connect to each other you will be prompted to form your number. Write it by clicking the numbers. You will use these number boxes later, for guessing your opponent's number. No number can begin with 0. After you both set your numbers, choose who will begin first. Oh I forgot, there's an internal chat program here! Just click the button with the arrow pointing down. It will show the chat screen. It can also hide it. After you "humanely" agree who will begin first, i.e. you, the game begins.
     It's time to guess your opponent's number. Click the number boxes and form your guess and click "Send". In the results box you will see your guess and two other numbers after it. The first one represents how many numbers you have guessed right and in the right place, while the second one shows how many numbers you have guessed right but in the wrong place (that you should change some of their places). Now it's time for your opponent to try a guess at yours. You will see his / her guess in his / her "Guesses" Box, and the same numbers, whose meanings are explained above.
     Thus, you will soon have enough data to form the right number. You will see how those special numbers help you to or not to use some numbers. The first one to guess his / her opponent's number, will occasionally win the game; and a new one will begin. The starter in here too, won't be decided by the program, for there are many versions of this game in real life and I don't want to restrict your liking of the game.
     This will go on like this until one of you give up.
     "Resign" button will resign the current game and declare your loss, then start a new game.
     "New Game" menu will prompt you and your opponent to start a new game. It will only do so if you both agree on it (I know of some people who won't use this humanely).

     Ok, and finally, have luck and lots of fun!

     DashiarD of DasHSofTR � 2002


Have fun! :)