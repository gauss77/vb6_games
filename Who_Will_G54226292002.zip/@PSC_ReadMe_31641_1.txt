Title: Who Will Guess the Number First? A Multiplayer Mastermind Example
Description: This is a game like Mastermind but this is played with numbers ranging 0 to 9. It is not a single player game, but multiplayer, played over a network with winsock.
You'll learn here;
-how to make a simple server-client connection,
-how to make a chat program
-how to open your default email client and send email to an assigned address
-how to use .ini files for local info (the nickname setting in the program is done by this)
-how to process strings with mid, left, format statements.
please vote if you like the program :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=31641&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
