Title: Bomber Game v2.2
Description: a update to my game bomber, a cool little game where you bomb planes, ships, and subs getting points when you do it. Oh and finally i added speed control (for all you peoples with the speed problems)!!! and last but not least there is a surprise if you have over 1000 and press P. please VOTE AND COMMENT!!!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=33138&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
