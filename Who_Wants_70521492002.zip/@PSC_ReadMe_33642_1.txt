Title: Who Wants To Be A Millionaire Better than all the rest(including mine. The diffrence is huge)
Description: This is the real Who |Wants To be a Millionaire game. this is a totaly new version. Superior graphics, question editor,introduction screen.
if you didnt like it before you will love it now.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=33642&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
