Game Keys:


Spacebar: makes yellow car go
Shift: Makes green car go


I hope that you enjoy the game!

Jonathan Santos
JJonathann@msn.com