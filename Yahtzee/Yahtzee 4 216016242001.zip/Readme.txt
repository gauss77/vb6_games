djs Windows Yahtzee by Dennis Stroh
djs314@hotmail.com

I wrote this as a learning experience in programing Visual Basic, this being my first
Visual Basic program.  The code may be a little muddled as I was learning new ways of
doing things and more about the language.

This is a full version game with complete source code.  It is colorful, easy and fun to play.

I used long variable names to make the code sort of self-commenting.

The game, I think is a fairly robust version of Yahtzee with these
helpful features:

* Tips on the point value of the dices after each roll,
* Highlighting of those scoring categories which will yield points
* Sound effects (which can be muted)
* Dice color choices
* A help section
* Four player capability
* Ability to save a game in progress
* Tracking of top 10 high scores

Let me know o9f any improvements or bugs.

Have Fun!!
Dennis Stroh
6/16/2001