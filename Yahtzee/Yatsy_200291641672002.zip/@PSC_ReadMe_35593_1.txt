Title: Yatsy 2002 a
Description: This is a update of yatzy 2002. What make this different from other Yatzy games, I have tried to get a more real feeling into it. Test it and comment what you think about it. Mabe you like it or just think this yatzy is nonsense. I like to thanks people for there comments I get for my early version of the game.
What differ from the early version.
1. I have make 3 degree of difficulty 
2. Make the gui look little better, but not much.
3. Better text help how to play.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=35593&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
