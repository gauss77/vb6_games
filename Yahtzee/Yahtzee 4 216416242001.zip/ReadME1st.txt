6/24/2001
Dennis Stroh
djs314@hotmail.com


Notes on loading and compiling Yahtzee 4 Player game.

I had trouble uploading the code to PlanetSourceCode, so the code is broken into two parts.

The first part has everything except the help files and the help form.  Note that the program expects the .wav files to be in a subdirectory named Sounds below the directory where the Yahtzee program is.  The Yahtzee.ini file can be edited to change this.

The second part has the help files.  The .frx file for form frmYahtzeeHS_Help apparently was preventing me from uploading the second part so I deleted it and added the .rtf files and .jpg files needed to reconstruct it.

Because the .frx file is not present you will probably get errors loading the form frmYahtzeeHS_Help (FrmHSHelp.frm) which means you may have to edit the form's code to change the paths for the fifteen .rtf and two .jpg files to suit your setup.  (There are more than two .jpg files in this zip file but they should already be in the .rtf files.)

1.  The .rtf files are all used in RichTextBoxes named HelpText(n), where n is 0 to 15.  
      Edit HelpText(n) FileName property to point to the location of the proper .rtf file.
      The value currently in the FileName property is the name of the .rtf file but
      without a path.  If the .rtf files are in the same directory as the rmYahtzeeHS_Help
      form VB may load them okay.

2.  There are two PictureBoxes on the frmYahtzeeHS_Help form which require .jpg images.  
      pctScreenLeft needs 75_yahtzee_screen-left.jpg
      pctScreenRight needs 75_yahtzee_screen-right.jpg

      I believe the Picture property of both of these PictureBoxes will have to be edited so that they contain the name of the proper .jpg file.  You can do this by clicking in the box next to the Picture property in the Properties Window.  Clicking on the box that appears (with 3 dots (...)) will bring up the load picture dialog.  You can navigate through the directory structure to where the .jpg files are located and click on them.


3.  The code was written using VB5 SP3 but the RichText Box used in the Help form is Microsoft RichText Box Control 6.0. 

Help this helps.