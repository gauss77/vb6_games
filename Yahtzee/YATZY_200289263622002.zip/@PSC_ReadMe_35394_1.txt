Title: YATZY 2002
Description: Yatzy 2002 Is a Game The Yatzy is made for the rules I used to play, but it easy to change to youre rules. Pleas tell me what you think about this game Good or bad, anything! And if you can pleas vote for it, if you find it usefull, good or maybe even bad! :-)
This is A absolutfree game But It's not legally to sell or distribute without my permission. 
If you want to have exe file of the game go to my homsite http://timelinesoft.vze.com/
Niklas

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=35394&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
