Title: Yahtzzzz
Description: Let's Play Yahtzee!!! This is a program that I created off of the old favorite dice game Yahtzee. I created a highscore function using the registry, each die gets rolled at least 10 times and you can even play 2 players.
The code is not completely tight right now, but if I get around to it, will replace this version with an update in the future.
If you like it, vote for it!!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=41474&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
