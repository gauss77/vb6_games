Title: Balldrop Game
Description: Simple ball catching game - silver balls drop from random places on the top of the form and you have to catch them with the paddle (follows the mouse cursor). The ball drops faster each time one is caught.
Keeps your score and can be paused. Fully commented for beginners - great program to learn from and under 10kb to download!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=44302&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
