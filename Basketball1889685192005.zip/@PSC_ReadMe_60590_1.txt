Title: Basketball scoreboard
Description: Add points x1 for each team, count down game time and 24 sec time and 60sec timeout, plays buzzer on timeout. playing with 2 timers, formats.. I was looking for bbal scoreboard - but it costs at least 1000$.. Well this is only first step - but i'll rather buy laptop and use this app..the effect is prety much the same.If any interest shows i can improve this - combining with flash graphics and IR controls.
This is my first upload- isn't hi-teach-pro, but is really cheap and potentialy usefull.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=60590&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
