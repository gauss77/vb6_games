Title: Chopper - 3D Choplifter game
Description: Chopper is basically a 3D version of teh Apple II classic, Choplifter. Your mission is to rescue hostages without being blown up by enemy tanks.
Make sure to read READ_FIRST.TXT
Please vote!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=51259&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
