Title: Asteroidz
Description: Complete game using Object Oriented Programming (OOP). Easy functionality, not optimized, so the code should be fairly easy to understand. Also implements Polymorphism, something rarely found in VB. Uses BitBlt (contained in a bitmap handler class), SndPlaySound (contained in a sound handler class), Enumerated keyboard input class and much more (please view the readme file). Any votes and/or comments would be greatly appreciated.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=36434&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
