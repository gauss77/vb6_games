			Quizard
		     By Amey Chaugule
	
	Quizard is all that remains of an ambitious multiplayer quiz project which was abandoned due to lack of time. The program generates random questions from its database  (53 questions).The software taunts you for a wrong answer while applauds a right answer. There is no point system in place hence the game continues even if u give wrong answer but nevertheless it is a fine example for newbies to Visual Basic. You can also add your questions to the database using a very helpful "Add a Question" function(See Screenshot). You may build up on this project to create exciting Quiz game of yours by adding music,scoring system, game types,time and ofcourse lots of questions! 

NOTE:Format of database = Type,Question,Options a,b,c,d, Reason , Apllad , Taunt

Regards,

ThAbR0oD
10th October 2004
� 2003 Braniac Softwares
Taunts � 2001 Pranav Bhonsule
