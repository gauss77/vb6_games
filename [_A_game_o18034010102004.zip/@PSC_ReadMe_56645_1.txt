Title: [ A game of Quizard ]
Description: 
	Quizard is all that remains of an ambitious multiplayer quiz project which was abandoned due to lack of time. The program generates random questions from its database (53 questions).The software taunts you for a wrong answer while applauds a right answer. There is no point system in place hence the game continues even if u give wrong answer but nevertheless it is a fine example for newbies to Visual Basic. You can also add your questions to the database using a very helpful "Add a Question" function(See Screenshot). You may build up on this project to create exciting Quiz game of yours by adding music,scoring system, game types,time and ofcourse lots of questions! 

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=56645&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
