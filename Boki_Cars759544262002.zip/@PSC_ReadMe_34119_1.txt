Title: Game - Boki Cars
Description: Someting I've made for my friend..It's a 2 player car racing game without collision detection. Keys are W,S,A,D for player 1 and cursors por player 2.
Great for learning BitBlt.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=34119&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
