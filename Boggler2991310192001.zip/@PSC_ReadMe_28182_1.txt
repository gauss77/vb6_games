Title: Boggler
Description: never loose at Boggle again. quickly, get all the possible word combinations in compliance with the rules of the game. now includes a workable ui implementing the boggler api. better randomization of letter combinations in the ui and now keeps score. to do: currently getting the definitions for all 161K+ words in dictionary.txt...will add interface for the definition in the iword class and update this source code when completed.
rate me please.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=28182&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
