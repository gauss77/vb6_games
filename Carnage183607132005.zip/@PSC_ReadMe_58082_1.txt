Title: Carnage
Description: This is a game where you and up to 7 other people have dogfights in planes. There is also the option to battle AI Planes. There are many cool features including: Alpha blended plane sprites, Customizable controls/colours, Scenery, nice background, sound and much more. It uses a render loop instead of a timer, and has NO VISIBLE CONTROLS at all, which means that it runs alot faster. I dont care about votes but please leave comments/sugestions.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=58082&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
