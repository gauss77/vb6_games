Title: Black Box 2b
Description: The main goal whit the game is to work out where 3 to 7 marbles are hidden on a table by geting clues. Don't sound so hard, but try it and be amazed. You must use you're brain to get good scores. Now it even have an timetrail, so it gets harder. 
NB This is not a finished produkt so you tests it on youre own responsibility !
It have been tested on Win/98 and Me and it's worked well there for me. It's only being tested with VB6.
Pleas give comments!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=33259&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
