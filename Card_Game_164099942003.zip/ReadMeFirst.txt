You can use the WordPad to view the source code (*.ajb, *.sol and *.cgf). I decided not to encrypt the files so that you can able to see the code. If you like it, please vote! :)

Open "MainGame.vbg"