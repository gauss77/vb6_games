Title: Card Game + Graph + SlideShow
Description: Cool GUI and Loads of Animation. This program has two games, each game stored in a file. To play the game just open the file. I've put a lot of animation here, so i hope 
you like it. ;)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=48254&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
