Public Class Form1
    Dim x As Integer
    Dim y(16), n, i, j As Integer
    Dim temp As String

    Public Function findx()
        If Button1.Text = "x" Then
            x = 1
        ElseIf Button2.Text = "x" Then
            x = 2
        ElseIf Button3.Text = "x" Then
            x = 3
        ElseIf Button4.Text = "x" Then
            x = 4
        ElseIf Button5.Text = "x" Then
            x = 5
        ElseIf Button6.Text = "x" Then
            x = 6
        ElseIf Button7.Text = "x" Then
            x = 7
        ElseIf Button8.Text = "x" Then
            x = 8
        ElseIf Button9.Text = "x" Then
            x = 9
        ElseIf Button10.Text = "x" Then
            x = 10
        ElseIf Button11.Text = "x" Then
            x = 11
        ElseIf Button12.Text = "x" Then
            x = 12
        ElseIf Button13.Text = "x" Then
            x = 13
        ElseIf Button14.Text = "x" Then
            x = 14
        ElseIf Button15.Text = "x" Then
            x = 15
        ElseIf Button16.Text = "x" Then
            x = 16
        End If
        Return x
    End Function

    Private Sub Button17_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button17.Click
        x = findx()
        If x = 5 Then
            Button5.Text = Button1.Text
            Button1.Text = "x"
        ElseIf x = 6 Then
            Button6.Text = Button2.Text
            Button2.Text = "x"
        ElseIf x = 7 Then
            Button7.Text = Button3.Text
            Button3.Text = "x"
        ElseIf x = 8 Then
            Button8.Text = Button4.Text
            Button4.Text = "x"
        ElseIf x = 9 Then
            Button9.Text = Button5.Text
            Button5.Text = "x"
        ElseIf x = 10 Then
            Button10.Text = Button6.Text
            Button6.Text = "x"
        ElseIf x = 11 Then
            Button11.Text = Button7.Text
            Button7.Text = "x"
        ElseIf x = 12 Then
            Button12.Text = Button8.Text
            Button8.Text = "x"
        ElseIf x = 13 Then
            Button13.Text = Button9.Text
            Button9.Text = "x"
        ElseIf x = 14 Then
            Button14.Text = Button10.Text
            Button10.Text = "x"
        ElseIf x = 15 Then
            Button15.Text = Button11.Text
            Button11.Text = "x"
        ElseIf x = 16 Then
            Button16.Text = Button12.Text
            Button12.Text = "x"
        End If
    End Sub

    Private Sub Button18_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button18.Click
        x = findx()
        If x = 1 Then
            Button1.Text = Button5.Text
            Button5.Text = "x"
        ElseIf x = 2 Then
            Button2.Text = Button6.Text
            Button6.Text = "x"
        ElseIf x = 3 Then
            Button3.Text = Button7.Text
            Button7.Text = "x"
        ElseIf x = 4 Then
            Button4.Text = Button8.Text
            Button8.Text = "x"
        ElseIf x = 5 Then
            Button5.Text = Button9.Text
            Button9.Text = "x"
        ElseIf x = 6 Then
            Button6.Text = Button10.Text
            Button10.Text = "x"
        ElseIf x = 7 Then
            Button7.Text = Button11.Text
            Button11.Text = "x"
        ElseIf x = 8 Then
            Button8.Text = Button12.Text
            Button12.Text = "x"
        ElseIf x = 9 Then
            Button9.Text = Button13.Text
            Button13.Text = "x"
        ElseIf x = 10 Then
            Button10.Text = Button14.Text
            Button14.Text = "x"
        ElseIf x = 11 Then
            Button11.Text = Button15.Text
            Button15.Text = "x"
        ElseIf x = 12 Then
            Button12.Text = Button16.Text
            Button16.Text = "x"
        End If
    End Sub

    Private Sub Button19_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button19.Click
        x = findx()
        If x = 1 Then
            Button1.Text = Button2.Text
            Button2.Text = "x"
        ElseIf x = 2 Then
            Button2.Text = Button3.Text
            Button3.Text = "x"
        ElseIf x = 3 Then
            Button3.Text = Button4.Text
            Button4.Text = "x"
        ElseIf x = 5 Then
            Button5.Text = Button6.Text
            Button6.Text = "x"
        ElseIf x = 6 Then
            Button6.Text = Button7.Text
            Button7.Text = "x"
        ElseIf x = 7 Then
            Button7.Text = Button8.Text
            Button8.Text = "x"
        ElseIf x = 9 Then
            Button9.Text = Button10.Text
            Button10.Text = "x"
        ElseIf x = 10 Then
            Button10.Text = Button11.Text
            Button11.Text = "x"
        ElseIf x = 11 Then
            Button11.Text = Button12.Text
            Button12.Text = "x"
        ElseIf x = 13 Then
            Button13.Text = Button14.Text
            Button14.Text = "x"
        ElseIf x = 14 Then
            Button14.Text = Button15.Text
            Button15.Text = "x"
        ElseIf x = 15 Then
            Button15.Text = Button16.Text
            Button16.Text = "x"
        End If
    End Sub

    Private Sub Button20_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button20.Click
        x = findx()
        If x = 2 Then
            Button2.Text = Button1.Text
            Button1.Text = "x"
        ElseIf x = 3 Then
            Button3.Text = Button2.Text
            Button2.Text = "x"
        ElseIf x = 4 Then
            Button4.Text = Button3.Text
            Button3.Text = "x"
        ElseIf x = 6 Then
            Button6.Text = Button5.Text
            Button5.Text = "x"
        ElseIf x = 7 Then
            Button7.Text = Button6.Text
            Button6.Text = "x"
        ElseIf x = 8 Then
            Button8.Text = Button7.Text
            Button7.Text = "x"
        ElseIf x = 10 Then
            Button10.Text = Button9.Text
            Button9.Text = "x"
        ElseIf x = 11 Then
            Button11.Text = Button10.Text
            Button10.Text = "x"
        ElseIf x = 12 Then
            Button12.Text = Button11.Text
            Button11.Text = "x"
        ElseIf x = 14 Then
            Button14.Text = Button13.Text
            Button13.Text = "x"
        ElseIf x = 15 Then
            Button15.Text = Button14.Text
            Button14.Text = "x"
        ElseIf x = 16 Then
            Button16.Text = Button15.Text
            Button15.Text = "x"
        End If
    End Sub

    Private Sub Button21_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        n = Math.Floor((16 - 1 + 1) * Rnd() + 1)
        While (i <= 16)
            For j = 1 To i
                While (y(j - 1) = n)
                    'MsgBox("Number already exist")
                    Button21_Click(sender, e)
                End While
            Next
            y(i) = n
            ' MsgBox("Number added" & n & "=" & i)
            i += 1
        End While
        Select Case (i)
            Case 1
                Button1.Text = y(i)
            Case 2
                Button2.Text = y(i)
            Case 3
                Button3.Text = y(i)
            Case 4
                Button4.Text = y(i)
            Case 5
                Button5.Text = y(i)
            Case 6
                Button6.Text = y(i)
            Case 7
                Button7.Text = y(i)
            Case 8
                Button8.Text = y(i)
            Case 9
                Button9.Text = y(i)
            Case 10
                Button10.Text = y(i)
            Case 11
                Button11.Text = y(i)
            Case 12
                Button12.Text = y(i)
            Case 13
                Button13.Text = y(i)
            Case 14
                Button14.Text = y(i)
            Case 15
                Button15.Text = y(i)
        End Select
    End Sub
End Class
