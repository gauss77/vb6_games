Title: _Wings of Fury
Description: This is a remake of the Apple IIe classic "Wings of Fury" You are a pilot of a P-51 Mustang and are attempting to rid islands of their inhabitans by strafing them.
 *WARNING* This is a work-in-progress. As to this date, the program runs but it is FAR from finished. I am submitting so that others may leave suggestions or use it to make their own game. It is heavily commented and should be easy to follow. I commented about BitBlt extremely well and this would be a great example for anyone learning it.
ENJOY!!!
Update 1: Now includes Pixel Collision for landing and the plane has guns
Update 2: Guns now kill people(little graves pop up, it's morbid but funny) and bullets kick up sand, dirt and water
Update 3: Bombs! They don't kill yet but they will
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=25664&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
