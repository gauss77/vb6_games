Title: A ZombiE AttacK Game - Need Help - Little Problem
Description: This is a little zombie attack game, where you have to shoot zombies that are coming after you. But There ius a small problem, and I need help to fix it. What happens is sometimes for no reson at all it will say game over when it is not supposed to, like as if one of the zombies got to you but they didnt.At first I thought maybe some were going off screen where you could see them and then they would pass the line to kill you, but I don't think that is it. Sometimes it works though. So please jhust take a look and if you think you know what it is please leave a comment telling me. Thanks a lot. Oh yha R is to reload.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=46265&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
