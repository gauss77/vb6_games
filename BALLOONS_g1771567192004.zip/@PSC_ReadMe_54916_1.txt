Title: BALLOONS game !!! (corrected)
Description: This is corrected version of the balloons game. Fixed the resolution problem and now game can be run in a window too.
Fire to balloons and do not let them get away.
If 3 get's away - Game over !
Keys:
Mouse move - move crosshair
P - pause the game
LMB - fire basic
RMB - fire bomb - destroys all balloons on the area (only 3 bombs)
ESC - end/exit game
If game runs too fast incerase value in the "Interval" of "tmr_Main" control or decarese it when it runs too slow.
This simple game can introduce a beginer to the Visual Basic API functions and not only - he can learn much more from the code. Download now and enjoy it. Don't forget to vote !!!

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=54916&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
