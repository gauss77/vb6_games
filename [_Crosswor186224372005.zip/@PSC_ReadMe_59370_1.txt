Title: [ Crossword/WordSearch Solver! ]
Description: This is a crossword/wordsearch solver (whichever one you call it). It is a full application, works perfectly on my computer. I attached a .cws (crossword solver) file in the ZIP. Start up the application, load up that cws file and press 'search'. It will search and make all found words in RED. With the cws I attached, the letters that are left should spell the word 'Wayne Gretzky' (the sample was taken out of my sisters crossword book). Please report bugs if any are found (not fixing bugs in user-edited .cws file.. not error checked yet). Comments, critisation and votes are all welcome.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=59370&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
