Title: City Bomber
Description: To teach collision detection. This is a Plane game that lets you bomb a city of you choice. The controls are the arrow keys and space bar to bomb. This is a pretty cool game. Plz vote
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=49155&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
