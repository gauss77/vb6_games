Title: Yatzee
Description: This game is the classic Yatzee game, the game is not my code, this means I have just changed a few of the original codes and a little graphic. It is Knoton who made the first version (His version avaliable here: http://www.planet-source-code.com/vb/scripts/showcode.asp?txtCodeId=24535&lngWId=1) 
I have added one more dice and a few more ways to play (This means three pair, etc) and a background.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=25327&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
