Title: BlackJack, no dlls needed
Description: Ok decided to make this game after i completed my videopoker game (isnt relised on planet source code just yet but is so much better) this like my video poker game doesnt use the card dll which so many use, it uses an array of 52 pictures. Also Ace can be either 11 or 1 the program will auto update the user/computer score for the best possible result for either to ensure that if an ace is added to a score of above 9 it will subtract 10 from the score to make the ace 1 apposed to 11 stopping busts that shudnt happen. other than that this program would be great example for arrays and shuffle routines used for many card games. the code is commented very well.
Feel free to edit this game anyway you wish or to use the code etc... would love to see or hear from who ever has. HOPE this helps sombody!
Oh sorry about the bad English.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=59585&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
