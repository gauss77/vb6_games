Title: BomberKids 1.2
Description: Another update to my bomberkids game.
The graphics still suck, but now there are a few effects. Look at the code for the flashy things and add em to ur program :) Obviously MORE UPDATES to come. supports only one bomb, one power of bomb so far.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=32207&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
