Title: wall-racers
Description: simple game.. try not to hit the walls created or the side, i havnt started work on graphics until it all works properly and need help with the AI to controll the computer players. any ideas will be welcomed.
please note code is very sloppy, as im still working on it, also it will create a log of all the moves the computer makes to help with debugging, and at the end wont clear the screen.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=62556&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
