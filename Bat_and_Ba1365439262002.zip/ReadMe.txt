player 1 controls- 
left = left arrow key
right= right arrow key
up = up arrow key
down = down arrow key
player2 controls-
left = a
right = d
up = w
down = s
