Title: Bat and Ball game
Description: This is a game where you must keep the ball off the ground. You get points everytime you hit the ball and when it hits the side of the screen.Has gravity and everything!!!!
I made this game a while ago so heres hopin its like what i remember :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=39281&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
