Title: UPDATED - A Subspace Replica
Description: If you're lucky, you've played the game Subspace (aka Continuum) If not, download it. Well, this is the beginning of my attempt to copy it. Even though it isn't finished, this is a complete program. The reason I've uploaded it now is just to show some examples of trig algorithms for movement and BitBlt being used in a loop. For me, starting to use BitBlt inside a continuous loop was difficult at first because it can be tricky to get rid of the flickering. Anyway, here's my code and how I did it. Oh yeah, also has an example of GetAsyncKeyState, a good API to know.
UPDATE: Bombs, Bullets, Explosions, Enemies, Walls, Energy Bar. If you downloaded it already, dowload it again! The program has reached the point where it is too big to upload so if you want an up-to-date version, just email me.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=35467&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
