
Bingo  V 1.0

This programm will be installed under the freeware agreement listed below.


FREEWARE AGREEMENT

1.You may use this programm for free and make as many copies of  the orginal content.

2.You may not sell the software.Instead you may give it away to any person. 

3.Marvensoft is not responsable for any damage using this software whatsoever.






if you have any questions or comments please mail to:       info@marvensoft.com

Oktober 20, 2001
www.marvensoft.com