Title: A VB Pong Game
Description: Go back to the old days with this classic pong game. You play against the computer, so this is man vs. machine. To move the paddle, you would use the up and down arrow keys on the keyboard. And yes, winning against the computer is possible, as long as you are careful with the position of the paddle. Good luck playing!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=62917&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
