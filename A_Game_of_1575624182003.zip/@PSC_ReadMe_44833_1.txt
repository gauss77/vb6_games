Title: A Game of Othello
Description: For some reason, I tried to re-upload and the entry got deleted. All bugs are (should be) fixed. Please RE-VOTE. Play a game of Othello against a rather tough-to-beat computer player, or another person. The AI is not "Chessmaster strength", but good luck beating it. It also gives you all possible moves and will give you a move suggestion. Code is not extremely well-commented, but it is not too difficult. Vote if you like, but vote honestly. Really look at the code and the program, I actually look at commments and use the votes to tell what people like and what they don't, so please be honest. Thank you.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=44833&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
