Title: A Space Arcade Game
Description: **FIXED FORM PROBLEM** This is my first ever 'game' so, it's probably bugged, and lots of messy code. It's done in VB and DirectDraw. Graphics made by Brady.
If it helps you, great - if not, sorry.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=54204&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
