Title: A Guessing Game by Nickwilboy
Description: This application helps you with rounding numbers and choosing random numbers. On this game, you choose an number then click "Guess" and then the computer chooses a number and if you get the same number the computer does, you win. This game also keeps track your your wins and loses. It isn't very fun, but you can learn how to use different coding. Also, this code doesn't use any timers!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=29103&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
