Title: Boggle Word Finder
Description: this is basically a brute force wordfinder for the game Boggle...it only finds words with up to 6 characters(to keep the runtime down)...a complete search takes 1 minute and 15 seconds on my 533MHz celeron...you can add more words to the dictionary file...i commented it pretty well...please comment and vote...thanks!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=32689&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
