Title: Box Game Revised
Description: I got the idea of this simple game(Codeid=41215), from Sehab, even though this truely isn't his game. I am posting this to show a new approach to the game than the way he coded it. It doesn't save; but it has been designed for multiple lvls of play, and the design makes it easier to code a bit of AI for it if you desire. I am not looking for votes since this is only a few hour side project. comments are welcome though.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=42080&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
