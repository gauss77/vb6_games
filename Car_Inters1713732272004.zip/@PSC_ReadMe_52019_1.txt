Title: Car Intersection
Description: This game include intersection with 8 cars. all cars driving without crash each other. the car get fuel when its over, stop on a red light.
sometimes the poice is comming...
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=52019&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
