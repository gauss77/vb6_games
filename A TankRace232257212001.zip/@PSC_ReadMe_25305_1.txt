Title: A TankRace game in VB! No joke! Check out screenshot!
Description: A tank racing game in VB! Guide race tank against 2 other computer players! Featuring collision detection, one track, crash scenes, and more! Check it out! Small zip file, worth your time. However, the computer players were made to only drive through this track. Making new tracks require(but no hard) heavy modifications. Basically, I had nothing to do and created this in a few minutes. Yes, there are(to some of you) a lot of timers. You may change that, but I wanted things to happen at different intervals, and squeezed as much as I can as each timer can do. If you like this game, a vote will be appreciated. If not, then please don't vote poorly.
Enjoy...
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=25305&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
