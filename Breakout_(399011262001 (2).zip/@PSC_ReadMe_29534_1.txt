Title: Breakout (with level editor)
Description: This is a simple clone of the game Arcanoid (Breakout). It got five different levels and three difficult levels.
It also got a high score list and various options (diff levels, and colours on the objects) that are saved from run time to run time and a very simple level editor.
Feel free to use the code however you like. And please give me feedback on what you think of it.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=29534&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
