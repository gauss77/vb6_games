Title: Connect 4 Clone
Description: This code will help you develop a better understanding of multi-dimensional arrays as well as give you a firm example on how to begin creating a game of your choice.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=34011&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
