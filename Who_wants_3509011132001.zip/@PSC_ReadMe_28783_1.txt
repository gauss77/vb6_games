Title: Who wants to be a Millonaire
Description: This game is a game copying Who Wants to be a Millionaire. What seperates it from other millionaire games (Well, those I have seen anyway), is that it uses an Access database for questions and answers. This makes editing the answers and questions a breze. While the code and time may seem not that great (And hey, it probably is at times, nobody is perfect) please post on how I could fix that.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=28783&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
