Hello All.

This is a 3D real time environment application.
It is just a 3D program using Direct3DRM not a game, but it could be
a good beginning about it.

The main code was written by K. Sudhakar (sudhakarj21@yahoo.com).

I have made some changes, Updating and additions, but most of the work
is due to Mr.Sudhakar; thanks to him.  

The original program helped me a lot to learn Direct3D expecially about 
different camera views and 3d sound and I hope this will help you too. 


Controls:

F1 - view from center
F2 - view from main road
F3 - view from helicopter 1
F4 - closed view
F5 - view from helicopter 2
F6 - your car (outside)
F7 - your car (inside)
F12 - night view on/off

1 - camera views on car 1
2 - camera views on car 2
3 - camera views on car 3
4 - camera views on car 4

with F6 (outside your car): 

Up cursor - go ahead
Down cursor - go back
Left cursor - turn left
Right cursor - turn right
Z - increase height view  
X - decrease height view  
Q - increase car distance
W - decrease car distance

with F7 (inside your car):

Up cursor - go ahead
Down cursor - go back
Left cursor - turn left
Right cursor - turn right
You can't turn if you aren't moving ahead or backward.

M - Music on/off



Collisions detection and lights (with night option) are not ready, yet. 

The next improvements will also contain a bit of car's physic, the join
between outside and inside car views, some trees and other environment objects.

I didn't use animations to moving the cars because of I dont't understand well 
how the Quarternion works,yet; if someone know about it, please contact me.

Everybody can modify the code or employ parts of it within own projects, but please
let me know about your projects and give me and Mr. K.Sudhakar a little credit.
Only one restriction: NOBODY MUST USE ANY PART OF THIS PROGRAM IN COMMERCIAL PURPOSES.

Enjoy this amazing app!

I would appreciate it if you give me feedback.

Every comments, suggestions, ideas and e-mails are always welcomed to:
fabiocalvi@yahoo.com

Bye, Fabio.