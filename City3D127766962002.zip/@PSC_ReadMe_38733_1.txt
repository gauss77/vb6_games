Title: City3D
Description: This is a 3D real time environment
application using Direct3DRM.See the Readme.txt file, please.
DirectX7 needed.
For other vb games and demos visit my web site: http://web.tiscali.it/fc_vbgames/index.html

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=38733&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
