Title: Card Deck class with a simple drawing method.
Description: (unable to upload images !!)Another card deck class, but i made mind cuz no one here was giving me the flexibility of a real deck class
or was too simple. With this little functional snipet you can create almost all kind of multiplayer card game like
hearts, canasta, pocker, black jack, spades, bridge and lot more, simple graphic method. Api's are used to load
graphic sets in memory and picture object for single card.
I have created Easy Deck in order to create multiple card games with multiple players a class has been designed to act has the deck object and the drawing method used here is bitblt on pictureboxes. � harveysolutions@t2u.com
The missing image is a jpg with 54 cards of 71x96 pixels (total 3834x71) create this file and save it in the same directory.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=42956&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
