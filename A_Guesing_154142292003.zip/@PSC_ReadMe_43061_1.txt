Title: A Guesing Game( The Guessser)
Description: This is a guessing game. the computer guesses a random number and you have to guess it.
Truely, I don't want any votes...I just want you to visit my web sites:
www.helloindia.4t.com
www.loveboard.2ya.com
www.cis.2ya.com
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=43061&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
