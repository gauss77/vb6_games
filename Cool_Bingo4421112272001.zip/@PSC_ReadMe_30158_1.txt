Title: Cool Bingo Game!!! MUST SEE!!!
Description: I played a real bingo game with some friends, but one of us had to be the one mixing the balls.. extracting them one at a time..
So this works just like a real Bingo game! It can also tell you what number was extracted, in 3 different languages. 
As I said, this is a quicky... Hope u guys can have some fun with it.. and.. why not.. gain some money.. :)
I included a ticked sample. You can create your own, print them (or draw them), and every player buys a ticked for a sum of money, and the one who gets the BINGO, get's all of it.. 
Beware.. u might become addicted!!!!
:)))
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=30158&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
