Title: Atomic War 2120
Description: War 2120 is a turn based strategy game that takes place years in the future when soldiers are now obsolite. missles, bombs, and chemicals are now the main weapons of the day, and rain down on cities cuasing havoc and destruction. You have the choice of launching 10 megaton atomic warheads, massive bombs, and chemical attacks to crush your enemy in an attempt to gain world domination.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=58202&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
