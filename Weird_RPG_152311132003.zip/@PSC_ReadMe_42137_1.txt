Title: Weird RPG Game
Description: I'm not expecting much comments or votes... 
This is my first game and I wanted to show it. 
It uses a code for collision detection that is not mine...
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=42137&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
