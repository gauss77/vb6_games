Title: Connect Four (aka The Captain's Mistress)
Description: During his long sea voyages, Captain Cook was often absent in the evenings and eventually the crew began to joke that he must have a mistress in his cabin. When they discovered that the Captain had simply been playing this game with the ship's scientists, the game was christened "The Captain's Mistress". ~~ This program uses bitmaps to represent the Board, iterative Search deepening, Alpha-Beta pruning, and Principal Variation search. No positional evaluation is made at the search tree leaves, it simply relies on search depth to find winning combinations. Search depth is about 10 to 12 with a two seconds time check (Advanced level). The program is hard to beat even in Beginner mode. See Screenshot. ~~ Download is 33kB.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=71858&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
