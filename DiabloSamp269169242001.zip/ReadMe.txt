

This is a game that i started which has a few neat options in it.
1. mouse clicks in the default view, make the character go to the clicked position.
2. There are 3 camera angles F5 is the default isometric angle, F6 is a closer view but doesnt work too well, and F7 is the Doom type camera angle( If you rotate the char in isometric view then hit F7 for Doomtype view, the char appears to face the camera, so hit F7 before rotating if you want it to work right.
3. The arrow keys rotate the character but he also faces the direction of the mouse click too.
4. The ctrl key makes him swing his sword.
5. There is some 2d animated fire that looks pretty cool, this is the only 2d stuff ,the rest is 3d. If you want to see the fire in F7 view, Press F7 and rotate to the left with cursor keys.
This was my beginning of a diablo rip off that got too hard too fast.
 
Good Luck,
Any questions email
mtari@mnsi.net
Festermt