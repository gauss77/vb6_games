Title: DiabloSamplecode
Description: Diablo-like start of a game that shows many cool techniques
with 3 camera angles F5,6, and 7. Camera follows character, animated movement 
2d fire that rises from ground. This is not a finished game but just a
sample to show how i did some things that others may be wondering how to do.
Please email me with any questions or comments at
mtari@mnsi.net and feel free to use the code in any way you want.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=27522&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
