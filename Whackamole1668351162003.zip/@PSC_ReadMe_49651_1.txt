Title: Whackamole Game
Description: -- Will Be Updated Shortly -- Its a simple whackamole game, please rate and comment it. all comments welcome <Screenshot Added>
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=49651&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
