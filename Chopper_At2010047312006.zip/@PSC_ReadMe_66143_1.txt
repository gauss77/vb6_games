Title: Chopper Attack II -Asim Abbasi
Description: This game is created in VB5. Its an advanced version of Chopper Attack developed in GW-Basic. Its a multi stage game. This game has the following additional features as compared to previous version created in GW-Basic. 
  Developed in windows oriented environment. 
  Graphics are superb. 
  3D simulated special fire blast. 
  Multistage. 
  Fuel Indicator is added. 
  Score Indicator is added. 
  Continue Button is provided. 
  Helicopter is attacked by Jets and missiles carrier vehicle. 
  Special 3D sound effects 
and much much more to be seen. 
Disclaimer:
Download &amp; use this software at your own risk. If something wrong happens to your system or anyone else system connected to your computer, neither Takveen nor the author would not be responsible!!!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=66143&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
