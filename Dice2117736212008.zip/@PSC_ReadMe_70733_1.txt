Title: Dice
Description: set of Dice to play board games with. can play with up to 5 dice, and anything from 0-10 throws per player per round, also has an unlimited thow capability. source and exe included, will run on XP not sure about other systems.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=70733&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
