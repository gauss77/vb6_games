Title: A Tic Tac Toe with great AI so that u can never beat the computer.
Description: A great game of Tic Tac Toe in which you can never beat the computer.
This is a Tic Tac Toe game which uses complex algorithms. It uses the magic squares theoy to check if player has won and for mking the computer moves. Consider a 3x3 board. Each square on the board is assigned a magic value as follows.
square(1)(1) = 8
square(1)(2) = 1
square(1)(3) = 6
square(2)(1) = 3
square(2)(2) = 5
square(2)(3) = 7
square(3)(1) = 4
square(3)(2) = 9
square(3)(3) = 2
Now, for a player to win, the sum of magic values of any 3 squares that he owns must be 15. This is the theory of magic squares. The computer moves are made after complex calculations so that the computer never loses in this game. Yes! you cannot beat the computer. You don't think so? Go ahead and try.
 The game and all its components were created by me. You can contact me at nithin_eee@yahoo.com
Thanks for playing Tic Tac Toe. And have a nice day :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=40049&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
