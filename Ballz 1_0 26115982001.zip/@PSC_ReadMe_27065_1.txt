Title: Ballz 1.0 (download working)
Description: Here is the game again, for some reason my first submission didn't work. This one should work :)
--------
This is a simple game where you have to catch the ball that drops from the top of the building, using a supermarket cart. There are 5 levels in total. As you go up each level, the ball starts to fall faster, and becomes harder to get. Please vote.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=27065&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
