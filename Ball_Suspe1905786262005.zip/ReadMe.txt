This code was originally created by Diego Caivano
http://pscode.com/vb/scripts/ShowCode.asp?txtCodeId=61334&lngWId=1
Translated By SPY-3 - Site: http://Tiamat-Studios.vze.com
I was curios what it said so i decided to translate it the best
i could. A few things to know i not only translated text
I also translated control names and comments and even the files names
so you can better understand whats being said/done.
Also some things you will see are: (look at text between them for
example #{T}# Translate #{T}#
#{T}# - This simply means what i think it says
#{CT}# - This means i couldnt translate it
Please vote for all the work i did translating or atleast leave feedback