Title: WordPuz  (Updated)
Description: Test your Brain with this nice Puzzle game.WordPuz shows you 6 letters. Now its your turn to find the possible words.Included: English and German Language Pack and Wordlist Tools to create your own Language Pack and Wordlists. Sept. 8.: Added Italian Language Pack.(Menu translation thru google) Sept. 9. Fixed 2 errors in Lng &amp; Wordlist tools see comments.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=66482&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
