Title: BlackBox
Description: The main goal whit the game is to work out where 4 balls are hidden on a table by geting clues. Don't sound so hard, but try it and be amazed. You must use you're brain to get good scores.
This game is made for my own learning purpose.

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=32081&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
