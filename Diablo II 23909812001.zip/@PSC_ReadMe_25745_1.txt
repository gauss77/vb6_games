Title: Diablo II Saved Game Editor  -  Update 1
Description: Well, if you saw the first version then I'm sure you know that this is a very good program. Now it's even better! It has a very nice GUI and many features! Features that were in the first and this one include: the ability to create new character profiles; change strength, dexterity, vitality, and energy; change life, mana, and stamina. In this version I fixed a lot of the names for the skills of the characters. I also began working on getting the values for each skill.<br>
I'm still working on being able to change the level of each skill. If you download the code you will be able to see that I have already added menus for each skill belonging to an Amazon, Sorceress, and Necromancer. Anyway, have fun and enjoy!<br>
Oh, and comments are appreciated! =)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=25745&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
