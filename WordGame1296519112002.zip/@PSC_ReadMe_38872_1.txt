Title: WordGame
Description: This is just a fun word scamble game. Using a dictionary.txt file, the program picks a random 6 letter word, scambles it and finds every other word possibility (2-letter thru 6-letters) using the re-arranged letters from the orignial 6-letter word. The player then has 90 sec to find as many of the mystery words as possible for points.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=38872&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
