Title: WordWiz V1
Description: These are codes for a clone of the Tetris game but instead of using blocks,letters drop from above to produce words from 3 to 5 letters are applied
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=60725&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
