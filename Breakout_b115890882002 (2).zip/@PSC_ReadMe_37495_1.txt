Title: Breakout by John Sheridan
Description: This is a breakout game. It has collision detection, loading a map from a file, and a simple way to have the ball move around the screen. Please vote, I put a lot of work into this project.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=37495&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
