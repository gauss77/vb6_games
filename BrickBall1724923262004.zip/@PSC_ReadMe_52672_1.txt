Title: BrickBall
Description: BrickBall is a breakout-type game that uses BitBlt very efficiently, in fact this game runs full speed on a 486! It is also made for 256-color systems. (uses a palette). If you want to make efficient 2D games, here is your start.
Use the mouse to move the paddle, and hit the ball into the bricks. There is also a level editor just in case you feel you need one..
Let me know how this works, vote if you like it!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=52672&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
