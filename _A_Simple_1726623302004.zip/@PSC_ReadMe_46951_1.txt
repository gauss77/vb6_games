Title: _A Simple Library Inventory System / Using ADO
Description: Dear friend, Im Philip V. Naparan a 17 yr old programmer from Philippines and you can visit my website www.philipnaparan.cjb.net for more info about me.This program that i have been uploaded is a simple program that i have created in just 2 days. This program help more to those beginner in vb programming to introduce to them the basic concept of relational database using ADO.This program include the use of adodc control and database connection in runtime(not in design view). Download this and it will help you a lot. By the way dont for get to vote this program.Thank you, happy exploring it and GOD bless. ITOY GAWANG PINOY!        *NOTE: THIS IS CODED FOR BEGINNERS ONLY..............
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=46951&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
