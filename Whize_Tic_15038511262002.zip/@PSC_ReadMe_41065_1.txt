Title: Whize Tic Tac Toe
Description: A simple game of Tic Tac Toe, which u can play with either a human opponent or with the COMPUTER itself. Yes, u can play the game with ur computer. Lets see, if u can beat ur computer at it. Simple level of Artifical Intelligence has been used to generate the computer's move. Fell free to use or modify it. And if u like it, plz dont forget to vote me. Also, if u find any bugs, plz report them to me.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=41065&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
