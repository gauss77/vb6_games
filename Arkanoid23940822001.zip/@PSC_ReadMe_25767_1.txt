Title: Arkanoid
Description: This is my version of the old Arkanoid game( If you don't know it see the sreenshot). The game include difrent type of enemies, bonuses and a level editor. I create 12 levels and you can modify them or just replace them with new levels. The collision is very good( determine the side of the collision). This code shows how to play wave sound from resource file. Please send me any suggestions to kicheto@goatrance.com and don't forget to vote for me!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=25767&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
