Hi, here is my Asteroids game clone.

I coded this program some months ago to test rotating sprites and explosions effects for
my first Space Defender game while coding the first versions of Space Defender 2 too;
passing time I stopped to code it to spend my time coding the Space Defender 2 final version, 
which I uploaded in this web site (you can download it searching this title or searching 
my author name).

So I have abandoned it in my PC, but many people continue to e-mail me asking for other 
space games over besides Space Defender and Space Defender 2;
therefore I have decided to upload it but how it is, unfinished.

It is playable but I never completed it and it has some bugs (ex.: physics of the collisions 
is not very good, the firing shots are not well lined up with ship axis and several others, sorry)
and I am working on others projects at this moment.

However I hope that you agree that this deserves a decent vote.

I hope someone could learn from it: I think is possible to find some interesting pieces of code 
and several ideas in it.

Before uploading it I have added DirectX 7 music and sound fx routines (the original version
used DirectX 5); if you don't have it you can plaY the game removing sound and music modules and 
comment or cancel the playsound and DX initialization calls: the remainder part of the program is utilizing some Windows API only.
 
Everybody can modify the code or employ parts of it within your own projects (please, a little 
credit, thanks).

Only one restriction: NOBODY MUST USE ANY PART OF THIS PROGRAM IN COMMERCIAL PURPOSES.

It could be funny to create a version with asteroids or player ship bouncing on the edges of the
screen.

Send this game to your friends, and have fun with it.
Feel encouraged to spread the program around the net.  

Happy coding and have fun! 

Emails are always welcomed: fabiocalvi@yahoo.com


AstroRocks Gameplay
-----------------------

Up Arrow Key = THRUST 
Left Arrow Key =  TURN LEFT
Right Arrow Key = TURN RIGHT
Ctrl key = FIRE 
Spacebar = HYPERSPACE (very usefull to stop your speed immediately and in dangerous moments)
Esc = QUIT GAME

Collisions with Big Asteroids and with Alien Ships are lethal.

Bonus: Blue cross = RESTORE SHIELDS
       Orange Star = POWERFUL WEAPON
       Green Diamond = INCREASE LIVES
 

The goal of AstroRocks is scoring as many points as possible destroying the asteroids and alien ships which are moving around you. Colliding with the big asteroids or with enemy ships will destroy your spaceship and cost you a life, the collision with the other asteroids or enemy bullets will cause
damages on your shields; when you are out of shields, you lost a life and When you are out of lives,
the game is over.

Well, that's all folks.
Enjoy and Goodbye, Fabio.