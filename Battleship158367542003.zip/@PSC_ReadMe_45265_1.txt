Title: Battleship v0.9
Description: This is the classic Battleship game that I have made in Visual Basic. It can be played over the internet or LAN. It's still an early version so there could be a few problems, but it seems to work pretty good on my two computers, and the game should be fully playable.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=45265&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
