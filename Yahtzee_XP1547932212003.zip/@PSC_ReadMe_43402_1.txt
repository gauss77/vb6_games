Title: Yahtzee XP
Description: Yahtzee XP - Fully Featured Game.
Features include: Save Game, Load Game, Multi-player, Click-2-Pick Score Box, TruVoice DirectSS Game Play Narrator, Multi-Colored 3D Dice, complete Help File(Help File Project included), and more. Application uses Learnout & Haupsies TruVoice Speech Synthesization, due to other functionality this application is only compatible on Windows NT 5(Win2k) and Windows NT 5.1(XP). Project was requested by a user of an old version of a 1996 Yahtzee game who wanted to improve an allready addicting game. Thank you, Alex Smoljanovic - Salex Software (C) 2003
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=43402&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
