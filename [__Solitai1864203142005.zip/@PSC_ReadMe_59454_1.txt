Title: [* Solitaire! *]
Description: Solitaire! This is a remake of the solitaire game that comes with Windows. I'm pretty sure there aren't any bugs, at least none that I've come across. Updated: added options, scoring, time and the ability to choose your deck back! The only difference between mine and Microsoft's now is undo.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=59454&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
