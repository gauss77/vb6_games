Title: Boggle Simulator
Description: My daughter likes to play Boggle. So I wrote her a Boggle game she could play anytime. The Boggle game is a lot of fun. So I got to thinking about all possible words that could be made from the Boggle board. So I wrote a couple more programs that simulate the game.
For the Boggle game, I was using the Enable dictionary. The first program I wrote, filtered the Enable dictionary to remove all words that could actually be spelled with the 16 dice in the game. Yes, there are 16 letter words taht can be spelled. The second program (the one I am inlcuding here) simulates boggle games. Its cool because I include my Boggle solver that can find all possible words in the puzzle in less than a second!
I had searched the internet for Boggle solvers. I found one that included several Class module and was hard to understand. Some other people protected their solvers like a pile of gold. to use my solver subroutine, just pass it an array of letters from the word you are looking for, and it can determine if the word is in the puzzle.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=71535&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
