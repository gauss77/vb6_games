Title: BlackJack
Description: This is my first game ever. Once again, I have not done any error debugging since I am completely self taught. Any comments on this project will be appreciated since I need to know where my skill level is.
Go to the URL below to get the OCX files since admin removes them. 
http://upload2.net/page/download/vTuUdxznBwNDB37/BlackJack.zip.html
VBCARDS.OCX was used for the cards.
Thank You.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=66986&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
