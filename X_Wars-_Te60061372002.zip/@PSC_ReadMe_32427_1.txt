Title: X Wars- Text Fighting game...NEED HELP WITH IMPROVEMENT!
Description: The base code for this was orginally from some code I found on PSC called "Chatroomz" But Ive made it alot better than its ancestor, Ive aded a dice roller, kick option, Disable all fighting, etc. I need someone to help me make an online rpg, like the one "JimCamel" is making. I will take any sugestions, An I would be happy if anyone wanted to help me make this project
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=32427&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
