Title: Bang Bang Clone!
Description: "This is a remake of an old 2-player game, where you was a cannon and you had to shoot at the other cannon. They are placed randomly in a random-generated landscape. The game simulates wind and gravity, so it's not so easy to destroy the adversary cannon. Tell me if you liked this, or suggestions, and VOTE!!"
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=33649&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
