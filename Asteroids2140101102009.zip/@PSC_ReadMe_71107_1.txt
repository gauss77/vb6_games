Title: Asteroids
Description: This is an asteroids game that involves 3 weapons (bullets, lock-on rockets and bombs), 5 asteroid types including an explosive asteroid, warp power-up, stars, a flame and smoke trail and great configuration tools! It has a nice size universe with clever rap round system.
You control your ship with the mouse and keyboard:
Mouse: Aim, shot bullets and move
Ctrl/Alt: Fire asteroid seeking missile
Space: Drop Bomb
Esc/F11 can be used to toggle full screen
P/Pause Break will pause the game
F1 will Restart the game
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=71107&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
