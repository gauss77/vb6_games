Title: Yatzee Game
Description: Recently, i saw an upload of a Yatzee game, so I decided to include my own version of a Yatzee game. I created the game in my first few days of vacation some years ago... for my Girlfriend. It support up to 6 players, has sound, cursor animation (not my code) and dice statistics, it is also bilingual (French-English) I don't remember why i did the bilingual stuff. But nice game.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=59403&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
