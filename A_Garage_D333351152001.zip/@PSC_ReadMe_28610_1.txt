Title: A Garage DB and Inventory system
Description: Complete application. Customers Database, inventory system, search databse records, cool gui, Debtors alert, password protected.
This application is suitable for a car shop. Whenever the mechanic finish a job on a car the only thing he has to do is to use the service wizard and select the parts he used from a list and the number of the parts. The application substract the number of parts used from the inventory and gives the subtotal and total price. 
(The login password is set to nothing for the moment so if you want to access the application just click the login button)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=28610&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
