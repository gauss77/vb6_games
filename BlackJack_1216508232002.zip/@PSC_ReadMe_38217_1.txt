Title: BlackJack for Windows
Description: Casino Blackjack cardgame in VB6 fully commented, and I think worth taking a look at (addictive !). There are even several different levels (tables) you can get to. You'll need the sccCards.dll made by Sean Street (thanks). The source for this dll can be found here on PSC.
If anyone has comment or tips please leave them here (and vote if you want).
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=38217&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
