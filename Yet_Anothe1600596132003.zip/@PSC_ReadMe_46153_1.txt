Title: Yet Another Hangman Game
Description: [Updated] Just a hangman game. Made it a while ago and it works differently from the other hangman games I have seen so far, so I gave it a makeover and posted it. Only 60 words to chose from but they can be changed easily. Average example of string manipulation... watch out for the nasty long line in the Guess sub. I still get lost in it myself sometimes hehe. Feel free to comment, positive or negative. [UPDATES: Word revealed when you die; Left$, Right$ and Mid$ used instead of Left, Right and Mid; Guessed letters now appear in a status bar]
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=46153&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
