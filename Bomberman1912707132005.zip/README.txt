THE CONTROLS:

player1

up - upkey
down - down key
left - left key
right - right key

bomb - control

player2

up-w
down-s
left-a
right-d
bomb-tab



please send all comments and request for credits(coz the sound files are not mine) to getfun2004@yahoo.com
or vbgamerx@yahoo.com






PLEASE HELP ME MAKE A AI FOR COMPUTER PLAYER