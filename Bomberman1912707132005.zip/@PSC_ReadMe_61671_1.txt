Title: Bomberman
Description: Everyone must have played this classic at one time or other. This is one of my favourite games. So I decided to do a remake. All basic features are included in the game. I have added lots of nice effect with sprite animation. The bomberman model was created with 3ds max. At present only two player game is possible. So you have to get a friend to play woth you to enjoy the game. I wanted to include a computer player bu could not figure out how to implement the A.I. If you can help in this regard then i will be grateful to you. The game and the source code is completely free so feel free to download the game, enjoy it if possible improve it. But if you change the game then please notify me. But dont try to sell the game or take credit for it. If you experience any difficulty in running the game then please mail me at vbgamerx@yahoo.com. But please notice that i am not responsible for any problem that occur to your computer after running the program. 

The following is the configuration of the PC in which the game was made and tested:- 
PIII - 530 MHz 
Ram 198
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=61671&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
