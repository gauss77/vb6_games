Title: Diablo2 Runes Organizer
Description: Did you ever play that popular game from Blizzard, Diablo2? If you're a fan and bought the expansion you'll love that program. The program look at which rune your caracter have and then display which rune words you can make, it also display the description of the rune word.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=27839&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
