Title: WAR card game using Microsoft Access Database
Description: This code demonstrates an easy way of making a simple card game using a Database to store your card values, card names, and picture strings. The game actually took very little coding. (Just make sure you keep the card pics in a folder titled "jpgs", and keep that folder, along with the database, all in the same folder as the .vbp itself.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=62279&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
