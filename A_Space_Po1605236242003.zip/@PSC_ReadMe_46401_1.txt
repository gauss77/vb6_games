Title: A Space Pong Game
Description: Space Pong is a one player pong game in a outer space setting. The objective is to keep the asteroid from getting past the blocker. The game is made more difficult by the reflector that is randomly moving throughout space and causing the asteroid to change direction. You recieve 25 points every time you block the asteroid.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=46401&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
