Title: Word Racer and Boggle Solver (UPDATED)
Description: I developed this to solve 'Yahoo Word Racer' games. You can put in a 'letter grid' of any shape or size - even ones with HOLES such as in round 4. (right now up to 10X10) and it will solve all of the possible REAL words (using the included dictionary). It would also work fine for Boggle. Since Word Racer is a fast-paced game, I have it set to only solve 3,4, and 5 letter words (unless there is a 'QU' in there in which case it will also solve 6 letters) 
One of the intersting things about my solver is that you can use groups of letters in each cell, and it could find words in combination of groups of letters.
If you want to have it solve longer words, simply add a new listbox to the lstWords array - giving it an index number equal to the number of letters wanted, and then modify the limits at the bottom of function "AddNextLetter"
Enjoy!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=34107&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
