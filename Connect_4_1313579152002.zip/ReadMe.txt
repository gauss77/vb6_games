This is a classic (Connect 4) game with many options like:
- 10 levels with two play methods (two brains).
- Setup any position to play.
- Solve for force winning moves.

Notice: you can use any part of code but after email the programer.

for more information about the game and about my other software 
email me at:

mdk@gawab.com
