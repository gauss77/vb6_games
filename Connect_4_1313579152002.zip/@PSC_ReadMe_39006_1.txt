Title: Connect 4  ver 1.02
Description: This is a classic (Connect 4) game with many options like:
- 10 levels with two play methods (two brains).
- Setup any position to play.
- Solve for force winning moves.
Notice: you can use any part of code but after email the programer.
for more information about the game and about my other software 
email me at:
mdk@gawab.com

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=39006&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
