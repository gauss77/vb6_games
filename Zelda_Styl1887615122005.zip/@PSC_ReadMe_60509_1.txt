Title: Zelda Style Adventure Game (Update)
Description: A ZeldaStyle Game that is in the works...in DirectX7. So far the mapping is almost complete, messaging is done and animation is about done. Soon to come are NPC's and fighting. Before running the game make sure u copy the font that is included and paste it in your C:\WINDOWS\FONTS folder.
You move the character using the arrow keys, and interact with the signposts etc...using "Enter."
Also...since i am not allowed to upload Binary files...go here http://www.geocities.com/danny33156/FreeImage.zip and place that .DLL in the same folder as the .exe . Have fun!
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=60509&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
