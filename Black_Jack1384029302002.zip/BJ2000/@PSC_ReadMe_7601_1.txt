Title: Black Jack 2000
Description: This a simple black jack game which is using vbcards.ocx to design and the game is with sound. 
This game is very similar to casion black jack. Only the split function is missing. The code zip file is include the vbcards.ocx file. If anyone has download this code, please leave a feed back here or e-mail to kyolinux@sinatown.com
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=7601&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
