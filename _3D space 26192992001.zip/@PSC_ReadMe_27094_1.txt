Title: _3D space *improved*
Description: A demo of an incomplete 3d engine for a strategy (space) game. It features a "sky box"(cylinder of stars) and the ability to load different models (with points, lines, faces and 2d sprites[eg. for planets]). Yet to implement filled faces and click detection. Can someone help me with this. When the user clicks on the screen I want to detect where it is in 3d space (it always be on the same plane as the planets [horizontal plane 15 below 0]).
Tell me how it runs on your computer. I get about 20 on my 1Ghz (uncompiled). Leave a comment/suggestion and PLEASE vote if you like it.
Controls are now:
Left, right, up and down: strafe around y plane.
w,s: move up and down.
a,d: spin.
r,f: look, up/down.
I've done this kind of control because of the intended genre (obviously it won't br keyboard operated.
Now backface removal is implemented, i might try to make this more efficient though.
Next up I will add filled faces, shading(ie angle of face determines face colour), and implement painters algorithm. This simply determins which face is fartest away and draws it first etc.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=27094&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
