Title: WordFindGame-Solver2
Description: This is the second version of my WordPuzzle solver!
I've improoved the search algorithm and made it 4 times faster!
	o You have a 15x20 sheet filled with letters
	o And you have a list of words you have to find in
	o The unused letters are a keyword
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=50435&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
