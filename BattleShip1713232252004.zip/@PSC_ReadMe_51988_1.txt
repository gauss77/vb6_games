Title: BattleShips
Description: BattleShips is a game with 2 human opponents playing over the network. It uses UDP (ports 4100 and 4101) protocol. One player acts as SERVER/HOST and the other as the CLIENT. Players choose their where they want to position their ships or the program can do it automatically. When players are ready they click the ready button. Whoever clicks ready first, gets to shoot first. Stats include where you have fired and where your opponent has fired, what your shot/hit ratio is, and how many ships are still in the game.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=51988&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
