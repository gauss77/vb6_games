Title: A reversi (othello) game with AI
Description: This is a program that uses alpha beta search to play reversi, at its highest level it searches 6 moves during the game plus playing the last 12 moves perfectly, so it plays at a really good level and it is hard to beat for most people, the game also includes a setup mode that lets you setup any position to play, and you can ask the computer to make a move suggstion for you, the code is well commented, so please vote or comment if you liked the code.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=55558&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
