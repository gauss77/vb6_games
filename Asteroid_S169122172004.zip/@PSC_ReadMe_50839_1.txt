Title: Asteroid Simulation (See ScreenShot)
Description: This is the very beginning of an Asteroid Clone. So far, you can select the # of asteroids to display, and there are a few debug options from the GUI. For now, this is all that there is, but it will eventually be a clone of the asteroids game. I figured it might be interesting to see the program grow. As it is now, the Rocks' Speeds, Slopes, sizes, etc.. are all randomly generated..but you can change that however you'd like.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=50839&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
