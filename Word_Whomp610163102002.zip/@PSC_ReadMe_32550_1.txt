Title: Word Whomp Redux
Description: A few weeks ago I saw a program that takes the letters generated from the word whomp game at www.pogo.com and produces the words to enter. It got me to thinking about how to improve it.
Well here is my attempt...
The interesting points:
  - The permutations are preprocessed and stored in a text file(s). The excel spreadsheet that generated the permutations is included.
  -This version of has a 71243 word dictionary that was compiled from various sources around the internet.
  -The program uses a binary search to search the dictionary file.
The only problem is that it generates too many words..
Check it out and see what you think...
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=32550&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
