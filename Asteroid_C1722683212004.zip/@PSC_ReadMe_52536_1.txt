Title: Asteroid Collisions (using the DotProduct)
Description: Watch Asteroids floating around in space bouncing off each other with the same realistic precision as billiard balls. No DirectX or OpenGL, just pure VB code that produces the most wonderful, mesmerizing zero-G display. This application builds on two of my previous submissions, namely the Asteroids game, and the DotProduct demonstration. It would be trivial to turn this into a 2D game of billiards. It�s also easy to change the shape of the asteroids into perfect speheres by adjusting variables in the �CreateRandomShapeAsteroid� routine. Comments are scattered everywhere throughout the code. As always, compile for speed. Press the space-bar to reset.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=52536&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
