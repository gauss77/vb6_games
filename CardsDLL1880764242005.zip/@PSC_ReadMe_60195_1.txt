Title: CardsDLL
Description: The start or a multi-card game program. I've already made what I think is one of the nicest draw poker games out there. And I began on a solitare game. I'm not sure how I'm going to do that yet. So I wouldn't try running that game. But I have some options, including card backs and all that good stuff. My Scorehand subroutine may be useful to anyone trying to figure out how to turn 5 1-52 integers into it's appropriate hand value (full house, three of a kind, ect.) if you can decode it . Any comments are welcome, and I realize I should comment, but this was made a while back, so I didn't really think about that then. Please comment and vote :)
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=60195&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
