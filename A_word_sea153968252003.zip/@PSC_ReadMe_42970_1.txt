Title: A word search puzzle game
Description: Like Word Search Puzzles? I made this for my G/F so I wouldnt have to spend $5 on a book every other day. This is a nice setup, has random word placement, so never have the same puzzle twice. It has some bugs still but you can work them out if you like. Different grid sizes, uses MSFlexGrid and an MDI format. Enjoy.
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=42970&lngWId=1

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
